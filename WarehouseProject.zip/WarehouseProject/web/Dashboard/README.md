 <h1>Basic Output</h1>

![image](https://github.com/user-attachments/assets/0803264a-7123-4d75-8c0a-b6d2e82448b8)
